# proj_23-24

Grupo 47
Duarte Cruz - ist1110181
Davi Rocha  - ist1113146